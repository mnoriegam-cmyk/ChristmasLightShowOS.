# Christmas Light Show OS — Android 1.0

Esta carpeta contiene el proyecto Android inicial.

## Qué incluye
- Aplicación Android nativa mínima que muestra una interfaz local mediante WebView.
- Panel visual con luces solares A/B, RGB, enchufes, escenas, brillo y secciones de música/horarios.
- Funciones de demostración que cambian el estado visual dentro de la app.

## Importante
Esta versión **NO controla todavía luces físicas**. Los botones son demostrativos. Para control real habrá que identificar las marcas, modelos, protocolos y controladores compatibles de cada dispositivo. No conectes módulos eléctricos ni fuentes de alimentación basándote únicamente en esta interfaz.

## Crear el APK en la nube desde un teléfono
El proyecto incluye `.github/workflows/build-apk.yml`. Para generar el APK:
1. Crea un repositorio nuevo en GitHub desde el navegador del teléfono.
2. Sube el contenido de esta carpeta al repositorio (no solamente el ZIP).
3. Abre la pestaña **Actions** del repositorio y habilita los workflows si GitHub lo solicita.
4. Ejecuta **Build Android APK**.
5. Al terminar, abre la ejecución y descarga el artefacto `ChristmasLightShowOS-debug-apk`.
6. Descomprime el artefacto y abre el APK en tu Samsung. Android puede pedir permiso para instalar desde el navegador/archivos; hazlo solo si reconoces el archivo generado desde tu propio repositorio.

## Datos técnicos
- Paquete: `com.christmaslightshow.os`
- Versión: `1.0.0`
- Android mínimo: 6.0 (API 23)
- Compilación: Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17
